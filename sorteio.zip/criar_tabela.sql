CREATE TABLE IF NOT EXISTS tb_contato_evento (
    id              BIGSERIAL PRIMARY KEY,
    nome            TEXT NOT NULL,
    tipo            TEXT NOT NULL CHECK (tipo IN ('Síndico','Administrador','Parceiro','Lead','Outro')),
    whatsapp        TEXT NOT NULL,
    id_condominio   TEXT,                -- preenchido quando o condomínio existe na base
    condominio_nome TEXT,                -- campos abaixo só quando NÃO existe na base
    cep             TEXT,
    logradouro      TEXT,
    numero          TEXT,
    complemento     TEXT,
    bairro          TEXT,
    cidade          TEXT,
    uf              CHAR(2),
    criado_em       TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_condominio CHECK (id_condominio IS NOT NULL OR (condominio_nome IS NOT NULL AND logradouro IS NOT NULL AND cidade IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS ix_contato_evento_cond ON tb_contato_evento (id_condominio);

-- Prêmios cadastrados pela equipe
CREATE TABLE IF NOT EXISTS tb_premio (
    id        BIGSERIAL PRIMARY KEY,
    nome      TEXT NOT NULL,
    peso      INT  NOT NULL DEFAULT 1 CHECK (peso > 0),   -- chance relativa
    ativo     BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);
